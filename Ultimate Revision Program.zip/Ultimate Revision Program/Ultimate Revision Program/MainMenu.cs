namespace Ultimate_Revision_Program
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show("Do you want to exit?","Are you sure?",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnQ1_Click(object sender, EventArgs e)
        {
            BankManagement form = new BankManagement();
            form.Show();
            this.Hide();
        }

        private void btnQ2_Click(object sender, EventArgs e)
        {
            InventoryLogin login = new InventoryLogin();
            login.Show();
            this.Hide();
        }
    }
}