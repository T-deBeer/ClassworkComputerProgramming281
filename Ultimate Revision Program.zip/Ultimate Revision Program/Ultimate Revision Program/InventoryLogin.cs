﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ultimate_Revision_Program
{
    public partial class InventoryLogin : Form
    {
        public InventoryLogin()
        {
            InitializeComponent();
        }

        private void btnPassword_Click(object sender, EventArgs e)
        {
            if (txtPassword.UseSystemPasswordChar)
            {
                txtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "Cashier01")
            {
                if (txtPassword.Text == "1234")
                {
                    MessageBox.Show("Successful Login, Welcome", "WELCOME");
                    InventoryManagement form = new InventoryManagement();
                    form.Show();
                    this.Hide();
                }
            }
        }
    }
}
