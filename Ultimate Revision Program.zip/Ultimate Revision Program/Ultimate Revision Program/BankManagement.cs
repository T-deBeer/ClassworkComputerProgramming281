﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ultimate_Revision_Program
{
    public partial class BankManagement : Form
    {
        double currentBalance = 0;
        public BankManagement()
        {
            InitializeComponent();
            currentBalance = double.Parse(txtCurrentAmount.Text);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtAmount.Text = "";
            lbxLog.Items.Clear();
            lbxLog.Items.Add("Amount\tCurrent Balance");
            lblError.Text = "";
        }

        private void btnDebit_Click(object sender, EventArgs e)
        {
            double amount = 0;
            Debit();
        }

        private void Debit()
        {
            double amount = 0;

            try
            {
                amount = Convert.ToDouble(txtAmount.Text);

                if (currentBalance>=amount)
                {
                    currentBalance -= amount;

                    txtCurrentAmount.Text = $"{currentBalance}";
                    lbxLog.Items.Add($"{amount}\t{currentBalance}");
                }
                else
                {
                    lblError.Text = "Debit amount exceeds current balance";
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message,"Error Occured",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show("Do you want to exit bank management?", "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                MainMenu menu = new MainMenu();
                menu.Show();
                this.Hide();
            }
        }

        private void btnCredit_Click(object sender, EventArgs e)
        {
            Credit();
        }

        private void Credit()
        {
            double amount = 0;

            try
            {
                amount = Convert.ToDouble(txtAmount.Text);
                currentBalance += amount;

                txtCurrentAmount.Text = $"{currentBalance}";
                lbxLog.Items.Add($"{amount}\t{currentBalance}");
                
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
