﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ultimate_Revision_Program
{
    public partial class InventoryManagement : Form
    {
        List<ProductQ2> productList = new List<ProductQ2>();
        public InventoryManagement()
        {
            InitializeComponent();
            string path = @".\ProductsForQ2.txt";
            string[] textFileLines = File.ReadAllLines(path);

            dgvProducts.ColumnCount = 4;
            dgvProducts.Columns[0].Name = ("Product Name");
            dgvProducts.Columns[1].Name = ("Product Barcode");
            dgvProducts.Columns[2].Name = ("Product Price");
            dgvProducts.Columns[3].Name = ("Product Stock");
            productList = populateList(textFileLines);
        }

        private List<ProductQ2> populateList(string[] lines)
        {
            List<ProductQ2> list = new List<ProductQ2>();


            foreach (var line in lines)
            {
                string[] parts = line.Split(",");

                try
                {
                    ProductQ2 product = new ProductQ2();
                    product.ProductName = parts[0];
                    product.ProductBarcode = parts[1];
                    product.ProductPrice = double.Parse(parts[2]);
                    product.AmountInStock = int.Parse(parts[3]);


                    list.Add(product);
                    product.PopulateProducts(dgvProducts);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message + $"\n{parts[0]} failed");
                }
            }

            return list;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show("Do you want to exit inventory management?", "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                MainMenu menu = new MainMenu();
                menu.Show();
                this.Hide();
            }
        }

        private void dgvProducts_Click(object sender, EventArgs e)
        {
            string selectedProduct = dgvProducts.SelectedCells[0].Value.ToString();
            DisplayItemInformation(selectedProduct);
        }

        private void DisplayItemInformation(string? selectedProduct)
        {

            foreach (var product in productList)
            {
                if (product.ProductName == selectedProduct || product.ProductBarcode == selectedProduct || product.AmountInStock.ToString() == selectedProduct || product.ProductPrice.ToString() == selectedProduct)
                {
                    txtBarcode.Text = product.ProductBarcode;
                    txtProductName.Text = product.ProductName;
                    txtPrice.Text = product.ProductPrice.ToString();
                    txtStock.Text = product.AmountInStock.ToString();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string searchName = txtSearch.Text;
            int count = 0;
            bool found = false;
            
            foreach (var product in productList)
            {
                count++;
                if (product.ProductName == searchName)
                {
                    MessageBox.Show($"{searchName} has been found in the product list at position {count}");
                    dgvProducts.ClearSelection();
                    dgvProducts.Rows[count-1].Cells[0].Selected = true;
                    DisplayItemInformation(searchName);
                    found = true;
                }
            }

            if (!found)
            {
                MessageBox.Show($"{searchName} has not been found in the product list");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            bool removed = false;
            foreach (var item in productList)
            {
                if (item.ProductName == txtProductName.Text)
                {
                    try
                    {
                        ProductQ2 product = new ProductQ2();
                        product.ProductName = txtProductName.Text;
                        product.ProductBarcode = txtBarcode.Text;
                        product.ProductPrice = double.Parse(txtPrice.Text);
                        product.AmountInStock = int.Parse(txtStock.Text);

                        productList.Remove(item);
                        productList.Add(product);
                    }
                    catch (Exception exception)
                    {
                        MessageBox.Show(exception.Message);
                    }
                    removed = true;
                }
            }

            if (!removed)
            {
                MessageBox.Show("You need to select an item first");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            bool removed = false;
            foreach (var item in productList)
            {
                if (item.ProductName == txtProductName.Text)
                {
                    productList.Remove(item);
                    removed = true;
                }
            }

            if (!removed)
            {
                MessageBox.Show("You need to select an item first");
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {

            foreach (var item in productList)
            {
                try
                {
                    if (item.ProductName == txtProductName.Name)
                    {
                        throw new AlreadyExsists(item.ProductName);
                    }
                    else
                    {
                        ProductQ2 product = new ProductQ2();
                        product.ProductName = txtProductName.Text;
                        product.ProductBarcode = txtBarcode.Text;
                        product.ProductPrice = double.Parse(txtPrice.Text);
                        product.AmountInStock = int.Parse(txtStock.Text);
                        productList.Add(product);
                        dgvProducts.Rows.Clear();

                        foreach (var pro in productList)
                        {
                            pro.PopulateProducts(dgvProducts);
                        }
                        break;
                    }
                }
                catch (AlreadyExsists exception)
                {
                    MessageBox.Show(exception.Message);
                }
            }

        }

        
        public class AlreadyExsists : Exception
        {
            public string productName;
            public AlreadyExsists(string productName)
                :base(String.Format("Product {0} already exsists",productName))
            {
            }
        }
    }
}
