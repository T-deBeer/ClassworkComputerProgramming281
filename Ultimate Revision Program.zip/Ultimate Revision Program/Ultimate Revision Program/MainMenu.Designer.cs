﻿namespace Ultimate_Revision_Program
{
    partial class MainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQ1 = new System.Windows.Forms.Button();
            this.btnQ2 = new System.Windows.Forms.Button();
            this.btnQ3 = new System.Windows.Forms.Button();
            this.btnQ4 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnQ1
            // 
            this.btnQ1.Location = new System.Drawing.Point(309, 95);
            this.btnQ1.Name = "btnQ1";
            this.btnQ1.Size = new System.Drawing.Size(432, 61);
            this.btnQ1.TabIndex = 0;
            this.btnQ1.Text = "Q1 - Bank Management";
            this.btnQ1.UseVisualStyleBackColor = true;
            this.btnQ1.Click += new System.EventHandler(this.btnQ1_Click);
            // 
            // btnQ2
            // 
            this.btnQ2.Location = new System.Drawing.Point(309, 187);
            this.btnQ2.Name = "btnQ2";
            this.btnQ2.Size = new System.Drawing.Size(432, 61);
            this.btnQ2.TabIndex = 1;
            this.btnQ2.Text = "Q2 - Inventory Management";
            this.btnQ2.UseVisualStyleBackColor = true;
            this.btnQ2.Click += new System.EventHandler(this.btnQ2_Click);
            // 
            // btnQ3
            // 
            this.btnQ3.Enabled = false;
            this.btnQ3.Location = new System.Drawing.Point(309, 276);
            this.btnQ3.Name = "btnQ3";
            this.btnQ3.Size = new System.Drawing.Size(432, 61);
            this.btnQ3.TabIndex = 2;
            this.btnQ3.Text = "Q3 - Student Management";
            this.btnQ3.UseVisualStyleBackColor = true;
            // 
            // btnQ4
            // 
            this.btnQ4.Enabled = false;
            this.btnQ4.Location = new System.Drawing.Point(309, 373);
            this.btnQ4.Name = "btnQ4";
            this.btnQ4.Size = new System.Drawing.Size(432, 61);
            this.btnQ4.TabIndex = 3;
            this.btnQ4.Text = "Q4 - Stundent Class Report";
            this.btnQ4.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(782, 495);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(220, 61);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1025, 568);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnQ4);
            this.Controls.Add(this.btnQ3);
            this.Controls.Add(this.btnQ2);
            this.Controls.Add(this.btnQ1);
            this.Name = "MainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnQ1;
        private Button btnQ2;
        private Button btnQ3;
        private Button btnQ4;
        private Button btnExit;
    }
}