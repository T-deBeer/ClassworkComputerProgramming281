﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ultimate_Revision_Program
{
    class ProductQ2
    {
        public ProductQ2()
        {
        }

        public ProductQ2(int amountInStock, string productBarcode, string productName, double productPrice)
        {
            AmountInStock = amountInStock;
            ProductBarcode = productBarcode;
            ProductName = productName;
            ProductPrice = productPrice;
        }

        public int AmountInStock { get; set; }
        public string ProductBarcode { get; set; }
        public string ProductName { get; set; }
        public double ProductPrice { get; set; }

        public void PopulateProducts(DataGridView dgv)
        {
            dgv.Rows.Add(this.ProductName, this.ProductBarcode, this.ProductPrice, this.AmountInStock);
        }
    }
}
