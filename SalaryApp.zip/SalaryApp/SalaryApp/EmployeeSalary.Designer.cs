﻿namespace SalaryApp
{
    partial class EmployeeSalary
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxEmployees = new System.Windows.Forms.ListBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.txtSur = new System.Windows.Forms.TextBox();
            this.txtJb = new System.Windows.Forms.TextBox();
            this.spnHourlyRate = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rtbWages = new System.Windows.Forms.RichTextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.spnHoursworked = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.spnHourlyRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnHoursworked)).BeginInit();
            this.SuspendLayout();
            // 
            // lbxEmployees
            // 
            this.lbxEmployees.FormattingEnabled = true;
            this.lbxEmployees.ItemHeight = 15;
            this.lbxEmployees.Location = new System.Drawing.Point(35, 46);
            this.lbxEmployees.Name = "lbxEmployees";
            this.lbxEmployees.Size = new System.Drawing.Size(210, 199);
            this.lbxEmployees.TabIndex = 0;
            this.lbxEmployees.SelectedIndexChanged += new System.EventHandler(this.lbxEmployees_SelectedIndexChanged);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(55, 286);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(174, 46);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(288, 356);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(174, 46);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete Employee";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(288, 286);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(174, 46);
            this.btnUpdate.TabIndex = 3;
            this.btnUpdate.Text = "Update Emplyee";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(476, 286);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(174, 46);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add Employee";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtFirst
            // 
            this.txtFirst.Location = new System.Drawing.Point(395, 43);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.Size = new System.Drawing.Size(190, 23);
            this.txtFirst.TabIndex = 5;
            // 
            // txtSur
            // 
            this.txtSur.Location = new System.Drawing.Point(395, 72);
            this.txtSur.Name = "txtSur";
            this.txtSur.Size = new System.Drawing.Size(190, 23);
            this.txtSur.TabIndex = 6;
            // 
            // txtJb
            // 
            this.txtJb.Location = new System.Drawing.Point(395, 114);
            this.txtJb.Name = "txtJb";
            this.txtJb.Size = new System.Drawing.Size(190, 23);
            this.txtJb.TabIndex = 7;
            // 
            // spnHourlyRate
            // 
            this.spnHourlyRate.DecimalPlaces = 2;
            this.spnHourlyRate.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.spnHourlyRate.Location = new System.Drawing.Point(395, 157);
            this.spnHourlyRate.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.spnHourlyRate.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.spnHourlyRate.Name = "spnHourlyRate";
            this.spnHourlyRate.Size = new System.Drawing.Size(190, 23);
            this.spnHourlyRate.TabIndex = 8;
            this.spnHourlyRate.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(313, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Firstname:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(313, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "Surname:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(313, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "Job Title:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(313, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "Hourly Rate:";
            // 
            // rtbWages
            // 
            this.rtbWages.Location = new System.Drawing.Point(687, 55);
            this.rtbWages.Name = "rtbWages";
            this.rtbWages.Size = new System.Drawing.Size(257, 188);
            this.rtbWages.TabIndex = 13;
            this.rtbWages.Text = "";
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(687, 286);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(174, 46);
            this.btnCalc.TabIndex = 14;
            this.btnCalc.Text = "Calulate Employee Wages";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // spnHoursworked
            // 
            this.spnHoursworked.DecimalPlaces = 2;
            this.spnHoursworked.Location = new System.Drawing.Point(395, 220);
            this.spnHoursworked.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.spnHoursworked.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnHoursworked.Name = "spnHoursworked";
            this.spnHoursworked.Size = new System.Drawing.Size(190, 23);
            this.spnHoursworked.TabIndex = 15;
            this.spnHoursworked.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(306, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "Hours Worked";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(476, 356);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(174, 46);
            this.btnReset.TabIndex = 17;
            this.btnReset.Text = "Reset Controls";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // EmployeeSalary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 414);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.spnHoursworked);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.rtbWages);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.spnHourlyRate);
            this.Controls.Add(this.txtJb);
            this.Controls.Add(this.txtSur);
            this.Controls.Add(this.txtFirst);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lbxEmployees);
            this.Name = "EmployeeSalary";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.spnHourlyRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnHoursworked)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListBox lbxEmployees;
        private Button btnExit;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private TextBox txtFirst;
        private TextBox txtSur;
        private TextBox txtJb;
        private NumericUpDown spnHourlyRate;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private RichTextBox rtbWages;
        private Button btnCalc;
        private NumericUpDown spnHoursworked;
        private Label label5;
        private Button btnReset;
    }
}