using Microsoft.VisualBasic;

namespace SalaryApp
{
    public partial class EmployeeSalary : Form
    {
        List<EmployeeModel> employees = DatabaseAccess.LoadEmployee();
        public EmployeeSalary()
        {
            InitializeComponent();
            loadEmployees();
        }

        private void loadEmployees()
        {
            lbxEmployees.Items.Clear();
            employees = DatabaseAccess.LoadEmployee();

            foreach (var item in employees)
            {
                lbxEmployees.Items.Add(item.Firstname);
            }
        }

        private void lbxEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (var item in employees)
            {
                if (lbxEmployees.SelectedItem.ToString() == item.Firstname)
                {
                    LoadItemInformation(item);
                }
            }
        }

        private void LoadItemInformation(EmployeeModel item)
        {
            txtFirst.Text = item.Firstname;
            txtSur.Text = item.Surname;
            txtJb.Text = item.JobTitle;
            spnHourlyRate.Value = (decimal)item.HourlyRate;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var confirmation = MessageBox.Show("Are you sure you want to exit.", "Exit the Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmation == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private bool AllFieldsEntered()
        {
            if (txtFirst.Text == "" || txtFirst.Text == " ")
            {
                MessageBox.Show("Your employee needs a firstname.");
                return false;
            }
            if (txtSur.Text == "" || txtSur.Text == " ")
            {
                MessageBox.Show("Your employee needs a Surname.");
                return false;
            }
            if (txtJb.Text == "" || txtJb.Text == " ")
            {
                MessageBox.Show("Your employee needs a JobTitle.");
                return false;

            }
            return true;
        }

        private void ResetControls()
        {
            txtFirst.Text = "";
            txtJb.Text = "";
            txtSur.Text = "";
            spnHourlyRate.Value = spnHourlyRate.Minimum;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (AllFieldsEntered())
            {
                var confirmation = MessageBox.Show("Are you sure you want to update the item.", "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirmation == DialogResult.Yes)
                {
                    foreach (var item in employees)
                    {
                        if (txtFirst.Text == item.Firstname)
                        {
                            EmployeeModel updatedEmp = new EmployeeModel();

                            try
                            {
                                updatedEmp.Firstname = txtFirst.Text;
                                updatedEmp.Surname = txtSur.Text;
                                updatedEmp.JobTitle = txtJb.Text;
                                updatedEmp.HourlyRate = spnHourlyRate.Value;

                                DatabaseAccess.UpdateEmp(updatedEmp, item.Firstname);

                                MessageBox.Show("The item has been updated in the database.");

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }

                            loadEmployees();
                            ResetControls();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("You need to select an item before you can update one.");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (AllFieldsEntered())
            {
                var confirmation = MessageBox.Show("Are you sure you want to add this item.", "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirmation == DialogResult.Yes)
                {
                    foreach (var item in employees)
                    {
                        if (txtFirst.Text == item.Firstname)
                        {
                            EmployeeModel updatedEmp = new EmployeeModel();

                            try
                            {
                                updatedEmp.Firstname = txtFirst.Text;
                                updatedEmp.Surname = txtSur.Text;
                                updatedEmp.JobTitle = txtJb.Text;
                                updatedEmp.HourlyRate = spnHourlyRate.Value;

                                DatabaseAccess.AddNewEmp(updatedEmp);

                                MessageBox.Show("The item has been updated in the database.");

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }

                            loadEmployees();
                            ResetControls();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("You need to select an item before you can update one.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (AllFieldsEntered())
            {
                var confirmation = MessageBox.Show("Are you sure you want to delete the item.", "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirmation == DialogResult.Yes)
                {
                    foreach (var item in employees)
                    {
                        if (txtFirst.Text == item.Firstname)
                        {

                            try
                            {
                                DatabaseAccess.DeleteEmp(item.Firstname);

                                MessageBox.Show("The item has been removed the database.");

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }

                            loadEmployees();
                            ResetControls();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("You need to select an item before you can delete one.");
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            rtbWages.Text = "";
            if (AllFieldsEntered())
            {

                foreach (var item in employees)
                {
                    if (txtFirst.Text == item.Firstname)
                    {
                        MessageBox.Show("Boi");
                        double grossIncome = Decimal.ToDouble(item.HourlyRate * (decimal)spnHoursworked.Value);
                        double incomeTax = 0.15 * grossIncome;
                        double netPay = grossIncome - incomeTax;

                        rtbWages.Text = ($"GROSS SALARY:\t\t{grossIncome}\nINCOME TAX:\t\t{grossIncome}\n=================================\nNET SALARY:\t\t{netPay}");
                    }
                }

            }
            else
            {
                MessageBox.Show("You need to select an employee.");
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetControls();
        }
    }
}