﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SQLite;
using Dapper;
using System.Data;

namespace SalaryApp
{
    class DatabaseAccess
    {
        public static List<EmployeeModel> LoadEmployee()
        {
            using (IDbConnection database = new SQLiteConnection(LoadConnectionString()))
            {
                var output = database.Query<EmployeeModel>("SELECT * FROM Employees", new DynamicParameters());
                return output.ToList();
            }
        }

        public static void AddNewEmp(EmployeeModel employee)
        {
            using (IDbConnection database = new SQLiteConnection(LoadConnectionString()))
            {
                database.Execute("INSERT INTO Employees (Firstname, Surname, JobTitle, HourlyRate) VALUES (@Firstname, @Surname, @JobTitle, @HourlyRate)", employee);
            }
        }

        public static void UpdateEmp(EmployeeModel emp, string name)
        {
            using (IDbConnection database = new SQLiteConnection(LoadConnectionString()))
            {
                database.Execute($"UPDATE Employees SET Firstname = @Firstname,Surname=@Surname,JobTitle=@JobTitle,HourlyRate=@HourlyRate WHERE Firstname = '{name}'", emp);
            }
        }

        public static void DeleteEmp(string name)
        {
            using (IDbConnection database = new SQLiteConnection(LoadConnectionString()))
            {
                database.Execute($"DELETE FROM Employees WHERE Firstname = '{name}'");
            }
        }

        private static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }
    }
}
