﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG281_Week3_Day2_Excercise1
{
    public partial class EmployeeInfo : Form
    {
        public EmployeeInfo()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            var confirmation = MessageBox.Show("Are you sure you want to return to menu.", "Exit the Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmation == DialogResult.Yes)
            {
                MainMenu form = new MainMenu();
                form.Show();
                form.WindowState = this.WindowState;
                this.Close();
            }
        }
    }
}
