using MetroSet_UI.Forms;
namespace PRG281_Week3_Day2_Excercise1
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var confirmation = MessageBox.Show("Are you sure you want to exit.", "Exit the Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmation == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnExcercise2_Click(object sender, EventArgs e)
        {
            BankingDetails form = new BankingDetails();
            form.Show();
            form.WindowState = this.WindowState;
            this.Hide();
        }

        private void btnEmployeeInformation_Click(object sender, EventArgs e)
        {
            EmployeeInfo form = new EmployeeInfo();
            form.Show();
            form.WindowState = this.WindowState;
            this.Hide();
        }
    }
}