﻿using MetroSet_UI.Forms;
using MetroSet_UI.Components;
using MetroSet_UI.Controls;
using MetroSet_UI;
namespace PRG281_Week3_Day2_Excercise1
{
    partial class BankingDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpLayout = new System.Windows.Forms.TableLayoutPanel();
            this.lbxEmployees = new MetroSet_UI.Controls.MetroSetListBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tlpInputs = new System.Windows.Forms.TableLayoutPanel();
            this.txtAccNo = new MetroSet_UI.Controls.MetroSetTextBox();
            this.txtNameOnAcc = new MetroSet_UI.Controls.MetroSetTextBox();
            this.txtBranchName = new MetroSet_UI.Controls.MetroSetTextBox();
            this.txtBankName = new MetroSet_UI.Controls.MetroSetTextBox();
            this.txtBanksortCode = new MetroSet_UI.Controls.MetroSetTextBox();
            this.btnBack = new MetroSet_UI.Controls.MetroSetButton();
            this.btnAddBankingDetails = new MetroSet_UI.Controls.MetroSetButton();
            this.tlpLayout.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tlpInputs.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpLayout
            // 
            this.tlpLayout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.tlpLayout.ColumnCount = 3;
            this.tlpLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.82503F));
            this.tlpLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.17497F));
            this.tlpLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 413F));
            this.tlpLayout.Controls.Add(this.lbxEmployees, 0, 1);
            this.tlpLayout.Controls.Add(this.lblTitle, 1, 0);
            this.tlpLayout.Controls.Add(this.lblTitle2, 2, 0);
            this.tlpLayout.Controls.Add(this.panel1, 1, 1);
            this.tlpLayout.Controls.Add(this.btnBack, 0, 2);
            this.tlpLayout.Controls.Add(this.btnAddBankingDetails, 2, 2);
            this.tlpLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpLayout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.tlpLayout.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tlpLayout.Location = new System.Drawing.Point(0, 0);
            this.tlpLayout.Name = "tlpLayout";
            this.tlpLayout.RowCount = 3;
            this.tlpLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.51193F));
            this.tlpLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75.48807F));
            this.tlpLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 178F));
            this.tlpLayout.Size = new System.Drawing.Size(1172, 664);
            this.tlpLayout.TabIndex = 0;
            // 
            // lbxEmployees
            // 
            this.lbxEmployees.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lbxEmployees.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.lbxEmployees.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.lbxEmployees.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lbxEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbxEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbxEmployees.HoveredItemBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.lbxEmployees.HoveredItemColor = System.Drawing.Color.DimGray;
            this.lbxEmployees.IsDerivedStyle = true;
            this.lbxEmployees.ItemHeight = 30;
            this.lbxEmployees.Items.Add("Employee1");
            this.lbxEmployees.Items.Add("Employee2");
            this.lbxEmployees.Items.Add("Employee3");
            this.lbxEmployees.Items.Add("Employee4");
            this.lbxEmployees.Items.Add("Employee5");
            this.lbxEmployees.Location = new System.Drawing.Point(3, 122);
            this.lbxEmployees.MultiSelect = false;
            this.lbxEmployees.Name = "lbxEmployees";
            this.lbxEmployees.SelectedIndex = -1;
            this.lbxEmployees.SelectedItem = null;
            this.lbxEmployees.SelectedItemBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.lbxEmployees.SelectedItemColor = System.Drawing.Color.White;
            this.lbxEmployees.SelectedText = null;
            this.lbxEmployees.SelectedValue = null;
            this.lbxEmployees.ShowBorder = true;
            this.lbxEmployees.ShowScrollBar = false;
            this.lbxEmployees.Size = new System.Drawing.Size(288, 360);
            this.lbxEmployees.Style = MetroSet_UI.Enums.Style.Custom;
            this.lbxEmployees.StyleManager = null;
            this.lbxEmployees.TabIndex = 0;
            this.lbxEmployees.ThemeAuthor = "Narwin";
            this.lbxEmployees.ThemeName = "MetroLite";
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI Emoji", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.lblTitle.Location = new System.Drawing.Point(297, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(458, 85);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "BANKING";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTitle2
            // 
            this.lblTitle2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTitle2.AutoSize = true;
            this.lblTitle2.Font = new System.Drawing.Font("Segoe UI Emoji", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.lblTitle2.Location = new System.Drawing.Point(761, 0);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(408, 85);
            this.lblTitle2.TabIndex = 3;
            this.lblTitle2.Text = "DETAILS";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tlpInputs);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(297, 122);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(458, 360);
            this.panel1.TabIndex = 4;
            // 
            // tlpInputs
            // 
            this.tlpInputs.ColumnCount = 1;
            this.tlpInputs.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpInputs.Controls.Add(this.txtAccNo, 0, 3);
            this.tlpInputs.Controls.Add(this.txtNameOnAcc, 0, 2);
            this.tlpInputs.Controls.Add(this.txtBranchName, 0, 1);
            this.tlpInputs.Controls.Add(this.txtBankName, 0, 0);
            this.tlpInputs.Controls.Add(this.txtBanksortCode, 0, 4);
            this.tlpInputs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpInputs.Location = new System.Drawing.Point(0, 0);
            this.tlpInputs.Name = "tlpInputs";
            this.tlpInputs.RowCount = 5;
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tlpInputs.Size = new System.Drawing.Size(458, 360);
            this.tlpInputs.TabIndex = 0;
            // 
            // txtAccNo
            // 
            this.txtAccNo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtAccNo.AutoCompleteCustomSource = null;
            this.txtAccNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtAccNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtAccNo.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtAccNo.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtAccNo.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtAccNo.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtAccNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtAccNo.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtAccNo.Image = null;
            this.txtAccNo.IsDerivedStyle = true;
            this.txtAccNo.Lines = null;
            this.txtAccNo.Location = new System.Drawing.Point(105, 123);
            this.txtAccNo.MaxLength = 32767;
            this.txtAccNo.Multiline = false;
            this.txtAccNo.Name = "txtAccNo";
            this.txtAccNo.ReadOnly = false;
            this.txtAccNo.Size = new System.Drawing.Size(248, 30);
            this.txtAccNo.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtAccNo.StyleManager = null;
            this.txtAccNo.TabIndex = 3;
            this.txtAccNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtAccNo.ThemeAuthor = "Narwin";
            this.txtAccNo.ThemeName = "MetroLite";
            this.txtAccNo.UseSystemPasswordChar = false;
            this.txtAccNo.WatermarkText = "Account No(8 digits)";
            // 
            // txtNameOnAcc
            // 
            this.txtNameOnAcc.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtNameOnAcc.AutoCompleteCustomSource = null;
            this.txtNameOnAcc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNameOnAcc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNameOnAcc.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtNameOnAcc.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtNameOnAcc.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtNameOnAcc.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtNameOnAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNameOnAcc.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtNameOnAcc.Image = null;
            this.txtNameOnAcc.IsDerivedStyle = true;
            this.txtNameOnAcc.Lines = null;
            this.txtNameOnAcc.Location = new System.Drawing.Point(105, 83);
            this.txtNameOnAcc.MaxLength = 32767;
            this.txtNameOnAcc.Multiline = false;
            this.txtNameOnAcc.Name = "txtNameOnAcc";
            this.txtNameOnAcc.ReadOnly = false;
            this.txtNameOnAcc.Size = new System.Drawing.Size(248, 30);
            this.txtNameOnAcc.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtNameOnAcc.StyleManager = null;
            this.txtNameOnAcc.TabIndex = 2;
            this.txtNameOnAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNameOnAcc.ThemeAuthor = "Narwin";
            this.txtNameOnAcc.ThemeName = "MetroLite";
            this.txtNameOnAcc.UseSystemPasswordChar = false;
            this.txtNameOnAcc.WatermarkText = "Name On Account";
            // 
            // txtBranchName
            // 
            this.txtBranchName.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtBranchName.AutoCompleteCustomSource = null;
            this.txtBranchName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBranchName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBranchName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtBranchName.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtBranchName.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtBranchName.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtBranchName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBranchName.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtBranchName.Image = null;
            this.txtBranchName.IsDerivedStyle = true;
            this.txtBranchName.Lines = null;
            this.txtBranchName.Location = new System.Drawing.Point(105, 45);
            this.txtBranchName.MaxLength = 32767;
            this.txtBranchName.Multiline = false;
            this.txtBranchName.Name = "txtBranchName";
            this.txtBranchName.ReadOnly = false;
            this.txtBranchName.Size = new System.Drawing.Size(248, 30);
            this.txtBranchName.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtBranchName.StyleManager = null;
            this.txtBranchName.TabIndex = 1;
            this.txtBranchName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtBranchName.ThemeAuthor = "Narwin";
            this.txtBranchName.ThemeName = "MetroLite";
            this.txtBranchName.UseSystemPasswordChar = false;
            this.txtBranchName.WatermarkText = "Branch Name";
            // 
            // txtBankName
            // 
            this.txtBankName.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtBankName.AutoCompleteCustomSource = null;
            this.txtBankName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBankName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBankName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtBankName.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtBankName.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtBankName.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtBankName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBankName.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtBankName.Image = null;
            this.txtBankName.IsDerivedStyle = true;
            this.txtBankName.Lines = null;
            this.txtBankName.Location = new System.Drawing.Point(105, 7);
            this.txtBankName.MaxLength = 32767;
            this.txtBankName.Multiline = false;
            this.txtBankName.Name = "txtBankName";
            this.txtBankName.ReadOnly = false;
            this.txtBankName.Size = new System.Drawing.Size(248, 30);
            this.txtBankName.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtBankName.StyleManager = null;
            this.txtBankName.TabIndex = 0;
            this.txtBankName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtBankName.ThemeAuthor = "Narwin";
            this.txtBankName.ThemeName = "MetroLite";
            this.txtBankName.UseSystemPasswordChar = false;
            this.txtBankName.WatermarkText = "Name of Bank";
            // 
            // txtBanksortCode
            // 
            this.txtBanksortCode.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtBanksortCode.AutoCompleteCustomSource = null;
            this.txtBanksortCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBanksortCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBanksortCode.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtBanksortCode.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtBanksortCode.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtBanksortCode.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtBanksortCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBanksortCode.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtBanksortCode.Image = null;
            this.txtBanksortCode.IsDerivedStyle = true;
            this.txtBanksortCode.Lines = null;
            this.txtBanksortCode.Location = new System.Drawing.Point(105, 159);
            this.txtBanksortCode.MaxLength = 32767;
            this.txtBanksortCode.Multiline = false;
            this.txtBanksortCode.Name = "txtBanksortCode";
            this.txtBanksortCode.ReadOnly = false;
            this.txtBanksortCode.Size = new System.Drawing.Size(248, 30);
            this.txtBanksortCode.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtBanksortCode.StyleManager = null;
            this.txtBanksortCode.TabIndex = 4;
            this.txtBanksortCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtBanksortCode.ThemeAuthor = "Narwin";
            this.txtBanksortCode.ThemeName = "MetroLite";
            this.txtBanksortCode.UseSystemPasswordChar = false;
            this.txtBanksortCode.WatermarkText = "Bank Sort Code(6 digits)";
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.btnBack.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.btnBack.DisabledForeColor = System.Drawing.Color.Gray;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnBack.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnBack.HoverTextColor = System.Drawing.Color.White;
            this.btnBack.IsDerivedStyle = false;
            this.btnBack.Location = new System.Drawing.Point(3, 551);
            this.btnBack.Name = "btnBack";
            this.btnBack.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnBack.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnBack.NormalTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.btnBack.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.btnBack.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.btnBack.PressTextColor = System.Drawing.Color.White;
            this.btnBack.Size = new System.Drawing.Size(288, 46);
            this.btnBack.Style = MetroSet_UI.Enums.Style.Custom;
            this.btnBack.StyleManager = null;
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Back To Menu";
            this.btnBack.ThemeAuthor = "Narwin";
            this.btnBack.ThemeName = "MyTheme";
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnAddBankingDetails
            // 
            this.btnAddBankingDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddBankingDetails.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.btnAddBankingDetails.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.btnAddBankingDetails.DisabledForeColor = System.Drawing.Color.Gray;
            this.btnAddBankingDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAddBankingDetails.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnAddBankingDetails.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnAddBankingDetails.HoverTextColor = System.Drawing.Color.White;
            this.btnAddBankingDetails.IsDerivedStyle = false;
            this.btnAddBankingDetails.Location = new System.Drawing.Point(761, 551);
            this.btnAddBankingDetails.Name = "btnAddBankingDetails";
            this.btnAddBankingDetails.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnAddBankingDetails.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnAddBankingDetails.NormalTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.btnAddBankingDetails.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.btnAddBankingDetails.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.btnAddBankingDetails.PressTextColor = System.Drawing.Color.White;
            this.btnAddBankingDetails.Size = new System.Drawing.Size(408, 46);
            this.btnAddBankingDetails.Style = MetroSet_UI.Enums.Style.Custom;
            this.btnAddBankingDetails.StyleManager = null;
            this.btnAddBankingDetails.TabIndex = 6;
            this.btnAddBankingDetails.Text = "Add Employee Banking Details ";
            this.btnAddBankingDetails.ThemeAuthor = "Narwin";
            this.btnAddBankingDetails.ThemeName = "MyTheme";
            // 
            // BankingDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1172, 664);
            this.Controls.Add(this.tlpLayout);
            this.Name = "BankingDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Banking Details Form";
            this.tlpLayout.ResumeLayout(false);
            this.tlpLayout.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tlpInputs.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private TableLayoutPanel tlpLayout;
        private MetroSetListBox lbxEmployees;
        private Label lblTitle;
        private Label lblTitle2;
        private Panel panel1;
        private TableLayoutPanel tlpInputs;
        private MetroSetTextBox txtAccNo;
        private MetroSetTextBox txtNameOnAcc;
        private MetroSetTextBox txtBranchName;
        private MetroSetTextBox txtBankName;
        private MetroSetTextBox txtBanksortCode;
        private MetroSetButton btnBack;
        private MetroSetButton btnAddBankingDetails;
    }
}