﻿using MetroSet_UI.Forms;
using MetroSet_UI.Components;
using MetroSet_UI.Controls;
using MetroSet_UI;
namespace PRG281_Week3_Day2_Excercise1
{
    partial class EmployeeInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpLayout = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.metroSetTextBox1 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.metroSetTextBox2 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.metroSetTextBox3 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.metroSetTextBox4 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.metroSetTextBox5 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tlpInputs = new System.Windows.Forms.TableLayoutPanel();
            this.txtAccNo = new MetroSet_UI.Controls.MetroSetTextBox();
            this.txtNameOnAcc = new MetroSet_UI.Controls.MetroSetTextBox();
            this.txtBranchName = new MetroSet_UI.Controls.MetroSetTextBox();
            this.txtBankName = new MetroSet_UI.Controls.MetroSetTextBox();
            this.txtBanksortCode = new MetroSet_UI.Controls.MetroSetTextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.btnBack = new MetroSet_UI.Controls.MetroSetButton();
            this.btnAddBankingDetails = new MetroSet_UI.Controls.MetroSetButton();
            this.tlpLayout.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tlpInputs.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpLayout
            // 
            this.tlpLayout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.tlpLayout.ColumnCount = 2;
            this.tlpLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.652F));
            this.tlpLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.348F));
            this.tlpLayout.Controls.Add(this.panel2, 0, 1);
            this.tlpLayout.Controls.Add(this.panel1, 1, 1);
            this.tlpLayout.Controls.Add(this.lblTitle, 0, 0);
            this.tlpLayout.Controls.Add(this.lblTitle2, 1, 0);
            this.tlpLayout.Controls.Add(this.btnBack, 0, 2);
            this.tlpLayout.Controls.Add(this.btnAddBankingDetails, 1, 2);
            this.tlpLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpLayout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.tlpLayout.Location = new System.Drawing.Point(0, 0);
            this.tlpLayout.Name = "tlpLayout";
            this.tlpLayout.RowCount = 3;
            this.tlpLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.51193F));
            this.tlpLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75.48807F));
            this.tlpLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 178F));
            this.tlpLayout.Size = new System.Drawing.Size(1187, 741);
            this.tlpLayout.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 141);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(618, 418);
            this.panel2.TabIndex = 5;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.metroSetTextBox1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.metroSetTextBox2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.metroSetTextBox3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.metroSetTextBox4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.metroSetTextBox5, 0, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(618, 418);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // metroSetTextBox1
            // 
            this.metroSetTextBox1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.metroSetTextBox1.AutoCompleteCustomSource = null;
            this.metroSetTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.metroSetTextBox1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.metroSetTextBox1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.metroSetTextBox1.Image = null;
            this.metroSetTextBox1.IsDerivedStyle = true;
            this.metroSetTextBox1.Lines = null;
            this.metroSetTextBox1.Location = new System.Drawing.Point(166, 199);
            this.metroSetTextBox1.MaxLength = 32767;
            this.metroSetTextBox1.Multiline = false;
            this.metroSetTextBox1.Name = "metroSetTextBox1";
            this.metroSetTextBox1.ReadOnly = false;
            this.metroSetTextBox1.Size = new System.Drawing.Size(285, 30);
            this.metroSetTextBox1.Style = MetroSet_UI.Enums.Style.Custom;
            this.metroSetTextBox1.StyleManager = null;
            this.metroSetTextBox1.TabIndex = 3;
            this.metroSetTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox1.ThemeAuthor = "Narwin";
            this.metroSetTextBox1.ThemeName = "MetroLite";
            this.metroSetTextBox1.UseSystemPasswordChar = false;
            this.metroSetTextBox1.WatermarkText = "Surname";
            // 
            // metroSetTextBox2
            // 
            this.metroSetTextBox2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.metroSetTextBox2.AutoCompleteCustomSource = null;
            this.metroSetTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.metroSetTextBox2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.metroSetTextBox2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.metroSetTextBox2.Image = null;
            this.metroSetTextBox2.IsDerivedStyle = true;
            this.metroSetTextBox2.Lines = null;
            this.metroSetTextBox2.Location = new System.Drawing.Point(166, 158);
            this.metroSetTextBox2.MaxLength = 32767;
            this.metroSetTextBox2.Multiline = false;
            this.metroSetTextBox2.Name = "metroSetTextBox2";
            this.metroSetTextBox2.ReadOnly = false;
            this.metroSetTextBox2.Size = new System.Drawing.Size(285, 30);
            this.metroSetTextBox2.Style = MetroSet_UI.Enums.Style.Custom;
            this.metroSetTextBox2.StyleManager = null;
            this.metroSetTextBox2.TabIndex = 2;
            this.metroSetTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox2.ThemeAuthor = "Narwin";
            this.metroSetTextBox2.ThemeName = "MetroLite";
            this.metroSetTextBox2.UseSystemPasswordChar = false;
            this.metroSetTextBox2.WatermarkText = "Other Names";
            // 
            // metroSetTextBox3
            // 
            this.metroSetTextBox3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.metroSetTextBox3.AutoCompleteCustomSource = null;
            this.metroSetTextBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.metroSetTextBox3.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox3.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.metroSetTextBox3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.metroSetTextBox3.Image = null;
            this.metroSetTextBox3.IsDerivedStyle = true;
            this.metroSetTextBox3.Lines = null;
            this.metroSetTextBox3.Location = new System.Drawing.Point(166, 116);
            this.metroSetTextBox3.MaxLength = 32767;
            this.metroSetTextBox3.Multiline = false;
            this.metroSetTextBox3.Name = "metroSetTextBox3";
            this.metroSetTextBox3.ReadOnly = false;
            this.metroSetTextBox3.Size = new System.Drawing.Size(285, 30);
            this.metroSetTextBox3.Style = MetroSet_UI.Enums.Style.Custom;
            this.metroSetTextBox3.StyleManager = null;
            this.metroSetTextBox3.TabIndex = 1;
            this.metroSetTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox3.ThemeAuthor = "Narwin";
            this.metroSetTextBox3.ThemeName = "MetroLite";
            this.metroSetTextBox3.UseSystemPasswordChar = false;
            this.metroSetTextBox3.WatermarkText = "Prefered Name";
            // 
            // metroSetTextBox4
            // 
            this.metroSetTextBox4.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.metroSetTextBox4.AutoCompleteCustomSource = null;
            this.metroSetTextBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.metroSetTextBox4.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox4.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.metroSetTextBox4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.metroSetTextBox4.Image = null;
            this.metroSetTextBox4.IsDerivedStyle = true;
            this.metroSetTextBox4.Lines = null;
            this.metroSetTextBox4.Location = new System.Drawing.Point(166, 74);
            this.metroSetTextBox4.MaxLength = 32767;
            this.metroSetTextBox4.Multiline = false;
            this.metroSetTextBox4.Name = "metroSetTextBox4";
            this.metroSetTextBox4.ReadOnly = false;
            this.metroSetTextBox4.Size = new System.Drawing.Size(285, 30);
            this.metroSetTextBox4.Style = MetroSet_UI.Enums.Style.Custom;
            this.metroSetTextBox4.StyleManager = null;
            this.metroSetTextBox4.TabIndex = 0;
            this.metroSetTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox4.ThemeAuthor = "Narwin";
            this.metroSetTextBox4.ThemeName = "MetroLite";
            this.metroSetTextBox4.UseSystemPasswordChar = false;
            this.metroSetTextBox4.WatermarkText = "Forename";
            // 
            // metroSetTextBox5
            // 
            this.metroSetTextBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.metroSetTextBox5.AutoCompleteCustomSource = null;
            this.metroSetTextBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.metroSetTextBox5.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox5.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox5.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.metroSetTextBox5.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.metroSetTextBox5.Image = null;
            this.metroSetTextBox5.IsDerivedStyle = true;
            this.metroSetTextBox5.Lines = null;
            this.metroSetTextBox5.Location = new System.Drawing.Point(166, 235);
            this.metroSetTextBox5.MaxLength = 32767;
            this.metroSetTextBox5.Multiline = false;
            this.metroSetTextBox5.Name = "metroSetTextBox5";
            this.metroSetTextBox5.ReadOnly = false;
            this.metroSetTextBox5.Size = new System.Drawing.Size(285, 30);
            this.metroSetTextBox5.Style = MetroSet_UI.Enums.Style.Custom;
            this.metroSetTextBox5.StyleManager = null;
            this.metroSetTextBox5.TabIndex = 4;
            this.metroSetTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox5.ThemeAuthor = "Narwin";
            this.metroSetTextBox5.ThemeName = "MetroLite";
            this.metroSetTextBox5.UseSystemPasswordChar = false;
            this.metroSetTextBox5.WatermarkText = "Address";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tlpInputs);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(627, 141);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(557, 418);
            this.panel1.TabIndex = 4;
            // 
            // tlpInputs
            // 
            this.tlpInputs.ColumnCount = 1;
            this.tlpInputs.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpInputs.Controls.Add(this.txtAccNo, 0, 3);
            this.tlpInputs.Controls.Add(this.txtNameOnAcc, 0, 2);
            this.tlpInputs.Controls.Add(this.txtBranchName, 0, 1);
            this.tlpInputs.Controls.Add(this.txtBankName, 0, 0);
            this.tlpInputs.Controls.Add(this.txtBanksortCode, 0, 4);
            this.tlpInputs.Controls.Add(this.panel3, 0, 5);
            this.tlpInputs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpInputs.Location = new System.Drawing.Point(0, 0);
            this.tlpInputs.Name = "tlpInputs";
            this.tlpInputs.RowCount = 6;
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 97F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tlpInputs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tlpInputs.Size = new System.Drawing.Size(557, 418);
            this.tlpInputs.TabIndex = 0;
            // 
            // txtAccNo
            // 
            this.txtAccNo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtAccNo.AutoCompleteCustomSource = null;
            this.txtAccNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtAccNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtAccNo.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtAccNo.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtAccNo.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtAccNo.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtAccNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtAccNo.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtAccNo.Image = null;
            this.txtAccNo.IsDerivedStyle = true;
            this.txtAccNo.Lines = null;
            this.txtAccNo.Location = new System.Drawing.Point(136, 181);
            this.txtAccNo.MaxLength = 32767;
            this.txtAccNo.Multiline = false;
            this.txtAccNo.Name = "txtAccNo";
            this.txtAccNo.ReadOnly = false;
            this.txtAccNo.Size = new System.Drawing.Size(285, 30);
            this.txtAccNo.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtAccNo.StyleManager = null;
            this.txtAccNo.TabIndex = 3;
            this.txtAccNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtAccNo.ThemeAuthor = "Narwin";
            this.txtAccNo.ThemeName = "MetroLite";
            this.txtAccNo.UseSystemPasswordChar = false;
            this.txtAccNo.WatermarkText = "Email Address";
            // 
            // txtNameOnAcc
            // 
            this.txtNameOnAcc.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtNameOnAcc.AutoCompleteCustomSource = null;
            this.txtNameOnAcc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNameOnAcc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNameOnAcc.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtNameOnAcc.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtNameOnAcc.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtNameOnAcc.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtNameOnAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNameOnAcc.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtNameOnAcc.Image = null;
            this.txtNameOnAcc.IsDerivedStyle = true;
            this.txtNameOnAcc.Lines = null;
            this.txtNameOnAcc.Location = new System.Drawing.Point(136, 141);
            this.txtNameOnAcc.MaxLength = 32767;
            this.txtNameOnAcc.Multiline = false;
            this.txtNameOnAcc.Name = "txtNameOnAcc";
            this.txtNameOnAcc.ReadOnly = false;
            this.txtNameOnAcc.Size = new System.Drawing.Size(285, 30);
            this.txtNameOnAcc.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtNameOnAcc.StyleManager = null;
            this.txtNameOnAcc.TabIndex = 2;
            this.txtNameOnAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNameOnAcc.ThemeAuthor = "Narwin";
            this.txtNameOnAcc.ThemeName = "MetroLite";
            this.txtNameOnAcc.UseSystemPasswordChar = false;
            this.txtNameOnAcc.WatermarkText = "Mobile Number";
            // 
            // txtBranchName
            // 
            this.txtBranchName.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtBranchName.AutoCompleteCustomSource = null;
            this.txtBranchName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBranchName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBranchName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtBranchName.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtBranchName.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtBranchName.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtBranchName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBranchName.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtBranchName.Image = null;
            this.txtBranchName.IsDerivedStyle = true;
            this.txtBranchName.Lines = null;
            this.txtBranchName.Location = new System.Drawing.Point(136, 101);
            this.txtBranchName.MaxLength = 32767;
            this.txtBranchName.Multiline = false;
            this.txtBranchName.Name = "txtBranchName";
            this.txtBranchName.ReadOnly = false;
            this.txtBranchName.Size = new System.Drawing.Size(285, 30);
            this.txtBranchName.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtBranchName.StyleManager = null;
            this.txtBranchName.TabIndex = 1;
            this.txtBranchName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtBranchName.ThemeAuthor = "Narwin";
            this.txtBranchName.ThemeName = "MetroLite";
            this.txtBranchName.UseSystemPasswordChar = false;
            this.txtBranchName.WatermarkText = "Telephone Number";
            // 
            // txtBankName
            // 
            this.txtBankName.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtBankName.AutoCompleteCustomSource = null;
            this.txtBankName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBankName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBankName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtBankName.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtBankName.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtBankName.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtBankName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBankName.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtBankName.Image = null;
            this.txtBankName.IsDerivedStyle = true;
            this.txtBankName.Lines = null;
            this.txtBankName.Location = new System.Drawing.Point(136, 64);
            this.txtBankName.MaxLength = 32767;
            this.txtBankName.Multiline = false;
            this.txtBankName.Name = "txtBankName";
            this.txtBankName.ReadOnly = false;
            this.txtBankName.Size = new System.Drawing.Size(285, 30);
            this.txtBankName.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtBankName.StyleManager = null;
            this.txtBankName.TabIndex = 0;
            this.txtBankName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtBankName.ThemeAuthor = "Narwin";
            this.txtBankName.ThemeName = "MetroLite";
            this.txtBankName.UseSystemPasswordChar = false;
            this.txtBankName.WatermarkText = "Postal Code";
            // 
            // txtBanksortCode
            // 
            this.txtBanksortCode.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtBanksortCode.AutoCompleteCustomSource = null;
            this.txtBanksortCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBanksortCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBanksortCode.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.txtBanksortCode.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtBanksortCode.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.txtBanksortCode.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.txtBanksortCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBanksortCode.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.txtBanksortCode.Image = null;
            this.txtBanksortCode.IsDerivedStyle = true;
            this.txtBanksortCode.Lines = null;
            this.txtBanksortCode.Location = new System.Drawing.Point(136, 224);
            this.txtBanksortCode.MaxLength = 32767;
            this.txtBanksortCode.Multiline = false;
            this.txtBanksortCode.Name = "txtBanksortCode";
            this.txtBanksortCode.ReadOnly = false;
            this.txtBanksortCode.Size = new System.Drawing.Size(285, 30);
            this.txtBanksortCode.Style = MetroSet_UI.Enums.Style.Custom;
            this.txtBanksortCode.StyleManager = null;
            this.txtBanksortCode.TabIndex = 4;
            this.txtBanksortCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtBanksortCode.ThemeAuthor = "Narwin";
            this.txtBanksortCode.ThemeName = "MetroLite";
            this.txtBanksortCode.UseSystemPasswordChar = false;
            this.txtBanksortCode.WatermarkText = "National Insurance Number";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dateTimePicker1);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 260);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(551, 155);
            this.panel3.TabIndex = 5;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePicker1.Location = new System.Drawing.Point(133, 42);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(285, 23);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.label1.Location = new System.Drawing.Point(133, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Date of Birth";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI Emoji", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.lblTitle.Location = new System.Drawing.Point(3, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(618, 85);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "EMPLOYEE";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTitle2
            // 
            this.lblTitle2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTitle2.AutoSize = true;
            this.lblTitle2.Font = new System.Drawing.Font("Segoe UI Emoji", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.lblTitle2.Location = new System.Drawing.Point(627, 0);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(557, 85);
            this.lblTitle2.TabIndex = 3;
            this.lblTitle2.Text = "INFROMATION";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnBack.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.btnBack.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.btnBack.DisabledForeColor = System.Drawing.Color.Gray;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnBack.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnBack.HoverTextColor = System.Drawing.Color.White;
            this.btnBack.IsDerivedStyle = false;
            this.btnBack.Location = new System.Drawing.Point(3, 628);
            this.btnBack.Name = "btnBack";
            this.btnBack.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnBack.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnBack.NormalTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.btnBack.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.btnBack.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.btnBack.PressTextColor = System.Drawing.Color.White;
            this.btnBack.Size = new System.Drawing.Size(288, 46);
            this.btnBack.Style = MetroSet_UI.Enums.Style.Custom;
            this.btnBack.StyleManager = null;
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Back To Menu";
            this.btnBack.ThemeAuthor = "Narwin";
            this.btnBack.ThemeName = "MyTheme";
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnAddBankingDetails
            // 
            this.btnAddBankingDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddBankingDetails.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.btnAddBankingDetails.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.btnAddBankingDetails.DisabledForeColor = System.Drawing.Color.Gray;
            this.btnAddBankingDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAddBankingDetails.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnAddBankingDetails.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnAddBankingDetails.HoverTextColor = System.Drawing.Color.White;
            this.btnAddBankingDetails.IsDerivedStyle = false;
            this.btnAddBankingDetails.Location = new System.Drawing.Point(627, 628);
            this.btnAddBankingDetails.Name = "btnAddBankingDetails";
            this.btnAddBankingDetails.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(201)))), ((int)(((byte)(202)))));
            this.btnAddBankingDetails.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnAddBankingDetails.NormalTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(242)))));
            this.btnAddBankingDetails.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.btnAddBankingDetails.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(91)))), ((int)(((byte)(100)))));
            this.btnAddBankingDetails.PressTextColor = System.Drawing.Color.White;
            this.btnAddBankingDetails.Size = new System.Drawing.Size(557, 46);
            this.btnAddBankingDetails.Style = MetroSet_UI.Enums.Style.Custom;
            this.btnAddBankingDetails.StyleManager = null;
            this.btnAddBankingDetails.TabIndex = 6;
            this.btnAddBankingDetails.Text = "Add Employee to System";
            this.btnAddBankingDetails.ThemeAuthor = "Narwin";
            this.btnAddBankingDetails.ThemeName = "MyTheme";
            // 
            // EmployeeInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1187, 741);
            this.Controls.Add(this.tlpLayout);
            this.Name = "EmployeeInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Information";
            this.tlpLayout.ResumeLayout(false);
            this.tlpLayout.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tlpInputs.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TableLayoutPanel tlpLayout;
        private Panel panel2;
        private TableLayoutPanel tableLayoutPanel1;
        private MetroSetTextBox metroSetTextBox1;
        private MetroSetTextBox metroSetTextBox2;
        private MetroSetTextBox metroSetTextBox3;
        private MetroSetTextBox metroSetTextBox4;
        private MetroSetTextBox metroSetTextBox5;
        private Label lblTitle;
        private Label lblTitle2;
        private MetroSetButton btnBack;
        private MetroSetButton btnAddBankingDetails;
        private Panel panel1;
        private TableLayoutPanel tlpInputs;
        private MetroSetTextBox txtAccNo;
        private MetroSetTextBox txtNameOnAcc;
        private MetroSetTextBox txtBranchName;
        private MetroSetTextBox txtBankName;
        private MetroSetTextBox txtBanksortCode;
        private Panel panel3;
        private Label label1;
        private DateTimePicker dateTimePicker1;
    }
}