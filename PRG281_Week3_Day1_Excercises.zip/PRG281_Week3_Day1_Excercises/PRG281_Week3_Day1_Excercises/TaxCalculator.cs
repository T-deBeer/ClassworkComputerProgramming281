﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG281_Week3_Day1_Excercises
{
    public partial class TaxCalculator : Form
    {
        public TaxCalculator()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MainMenu form = new MainMenu();
            form.Show();
            this.Hide();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double amount = 0;

            try
            {
                amount = Convert.ToDouble(txtAmount.Text);

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
            finally
            {
                txtWithTax.Text = $"{Math.Round(amount + (amount * 0.15),2)}";
            }
        }

        private void btnBack_MouseEnter(object sender, EventArgs e)
        {
            btnBack.BackColor = Color.FromArgb(255, 57, 62, 70);
        }

        private void btnBack_MouseLeave(object sender, EventArgs e)
        {
            btnBack.BackColor = Color.FromArgb(255, 0, 173, 183);
        }

        private void btnCalc_MouseEnter(object sender, EventArgs e)
        {
            btnCalc.BackColor = Color.FromArgb(255, 57, 62, 70);
        }

        private void btnCalc_MouseLeave(object sender, EventArgs e)
        {
            btnCalc.BackColor = Color.FromArgb(255, 0, 173, 183);
        }

        private void TaxCalculator_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
