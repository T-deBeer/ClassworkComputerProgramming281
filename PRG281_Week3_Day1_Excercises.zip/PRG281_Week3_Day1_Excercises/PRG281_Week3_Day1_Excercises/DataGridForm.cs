﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG281_Week3_Day1_Excercises
{
    public partial class DataGridForm : Form
    {
        class Person
        {
            public Person()
            {
            }

            public Person(string firstname, string surname, string gender, string age, string dateOfBirth)
            {
                Firstname = firstname;
                Surname = surname;
                Gender = gender;
                Age = age;
                DateOfBirth = dateOfBirth;
            }

            public string Firstname { get; set; }
            public string Surname { get; set; }
            public string Gender { get; set; }
            public string Age { get; set; }
            public string DateOfBirth { get; set; }
        }

        List<Person> persons = new List<Person>();

        public DataGridForm()
        {
            InitializeComponent();
            dgvPeople.ColumnCount = 5;
            dgvPeople.Columns[0].Name = "Firstname";
            dgvPeople.Columns[1].Name = "Surname";
            dgvPeople.Columns[2].Name = "Gender";
            dgvPeople.Columns[3].Name = "Age";
            dgvPeople.Columns[4].Name = "Date of Birth";

            cbxGender.SelectedIndex = 0;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MainMenu form = new MainMenu();
            form.Show();
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Person person = new Person();
            bool error = false;


            try
            {
                person.Firstname = txtName.Text;
                person.Surname = txtSurName.Text;
                person.Gender = cbxGender.Items[cbxGender.SelectedIndex].ToString();
                person.Age = spnAge.Value.ToString();
                person.DateOfBirth = DateOnly.FromDateTime(dtpDOB.Value.Date).ToString();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message + " ,try again");
                error = true;
            }
            finally
            {
                if (!error)
                {
                    persons.Add(person);
                    txtName.Text = "";
                    txtSurName.Text = "";
                    spnAge.Value = spnAge.Minimum;
                    dtpDOB.Value = DateTime.Today;
                }
            }

        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            foreach (var person in persons)
            {
                dgvPeople.Rows.Add(person.Firstname, person.Surname,person.Gender,person.Age,person.DateOfBirth);
            }
        }

        private void spnAge_ValueChanged(object sender, EventArgs e)
        {
            dtpDOB.Value = DateTime.Today.AddYears(-(int)spnAge.Value);
        }
    }
}
