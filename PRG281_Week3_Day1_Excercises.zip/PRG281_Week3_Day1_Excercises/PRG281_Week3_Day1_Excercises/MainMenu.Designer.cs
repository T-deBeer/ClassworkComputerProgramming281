﻿namespace PRG281_Week3_Day1_Excercises
{
    partial class MainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMath = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnDgv = new System.Windows.Forms.Button();
            this.btnTaxCalculator = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMath
            // 
            this.btnMath.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnMath.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMath.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnMath.Location = new System.Drawing.Point(95, 107);
            this.btnMath.Name = "btnMath";
            this.btnMath.Size = new System.Drawing.Size(240, 45);
            this.btnMath.TabIndex = 0;
            this.btnMath.Text = "Excercise 1 - Do Some Math";
            this.btnMath.UseVisualStyleBackColor = false;
            this.btnMath.Click += new System.EventHandler(this.btnMath_Click);
            this.btnMath.MouseEnter += new System.EventHandler(this.btnMath_MouseHover);
            this.btnMath.MouseLeave += new System.EventHandler(this.btnMath_MouseLeave);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnExit.Location = new System.Drawing.Point(95, 318);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(240, 45);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit The Program";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            this.btnExit.MouseEnter += new System.EventHandler(this.btnExit_MouseEnter);
            this.btnExit.MouseLeave += new System.EventHandler(this.btnExit_MouseLeave);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(65, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(301, 40);
            this.lblTitle.TabIndex = 4;
            this.lblTitle.Text = "PRG281 Week 3 Day 1";
            // 
            // btnDgv
            // 
            this.btnDgv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnDgv.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDgv.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnDgv.Location = new System.Drawing.Point(95, 168);
            this.btnDgv.Name = "btnDgv";
            this.btnDgv.Size = new System.Drawing.Size(240, 45);
            this.btnDgv.TabIndex = 5;
            this.btnDgv.Text = "Excercise 2 - Data Grid View";
            this.btnDgv.UseVisualStyleBackColor = false;
            this.btnDgv.Click += new System.EventHandler(this.btnDgv_Click);
            this.btnDgv.MouseEnter += new System.EventHandler(this.btnDgv_MouseEnter);
            this.btnDgv.MouseLeave += new System.EventHandler(this.btnDgv_MouseLeave);
            // 
            // btnTaxCalculator
            // 
            this.btnTaxCalculator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnTaxCalculator.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTaxCalculator.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnTaxCalculator.Location = new System.Drawing.Point(95, 230);
            this.btnTaxCalculator.Name = "btnTaxCalculator";
            this.btnTaxCalculator.Size = new System.Drawing.Size(240, 45);
            this.btnTaxCalculator.TabIndex = 6;
            this.btnTaxCalculator.Text = "Excercise 3 - Tax Calculator";
            this.btnTaxCalculator.UseVisualStyleBackColor = false;
            this.btnTaxCalculator.Click += new System.EventHandler(this.btnTaxCalculator_Click);
            this.btnTaxCalculator.MouseEnter += new System.EventHandler(this.btnTaxCalculator_MouseEnter);
            this.btnTaxCalculator.MouseLeave += new System.EventHandler(this.btnTaxCalculator_MouseLeave);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(40)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(442, 375);
            this.Controls.Add(this.btnTaxCalculator);
            this.Controls.Add(this.btnDgv);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnMath);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnMath;
        private Button btnExit;
        private Label lblTitle;
        private Button btnDgv;
        private Button btnTaxCalculator;
    }
}