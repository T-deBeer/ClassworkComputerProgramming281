﻿namespace PRG281_Week3_Day1_Excercises
{
    partial class MathWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcMathPages = new System.Windows.Forms.TabControl();
            this.tpAddNumbers = new System.Windows.Forms.TabPage();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.tpSubtract = new System.Windows.Forms.TabPage();
            this.btnBack2 = new System.Windows.Forms.Button();
            this.lblAnswer2 = new System.Windows.Forms.Label();
            this.btnSubtract = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSubNum2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSubNum1 = new System.Windows.Forms.TextBox();
            this.tpMulti = new System.Windows.Forms.TabPage();
            this.btnBack3 = new System.Windows.Forms.Button();
            this.lblAnswer3 = new System.Windows.Forms.Label();
            this.btnMult = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMultNum2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMultNum1 = new System.Windows.Forms.TextBox();
            this.tbcMathPages.SuspendLayout();
            this.tpAddNumbers.SuspendLayout();
            this.tpSubtract.SuspendLayout();
            this.tpMulti.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcMathPages
            // 
            this.tbcMathPages.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tbcMathPages.Controls.Add(this.tpAddNumbers);
            this.tbcMathPages.Controls.Add(this.tpSubtract);
            this.tbcMathPages.Controls.Add(this.tpMulti);
            this.tbcMathPages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcMathPages.Location = new System.Drawing.Point(0, 0);
            this.tbcMathPages.Name = "tbcMathPages";
            this.tbcMathPages.SelectedIndex = 0;
            this.tbcMathPages.Size = new System.Drawing.Size(829, 492);
            this.tbcMathPages.TabIndex = 0;
            // 
            // tpAddNumbers
            // 
            this.tpAddNumbers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(40)))), ((int)(((byte)(49)))));
            this.tpAddNumbers.Controls.Add(this.btnBack);
            this.tpAddNumbers.Controls.Add(this.lblAnswer);
            this.tpAddNumbers.Controls.Add(this.btnAdd);
            this.tpAddNumbers.Controls.Add(this.lblNum2);
            this.tpAddNumbers.Controls.Add(this.txtNum2);
            this.tpAddNumbers.Controls.Add(this.lblNum1);
            this.tpAddNumbers.Controls.Add(this.txtNum1);
            this.tpAddNumbers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.tpAddNumbers.Location = new System.Drawing.Point(4, 27);
            this.tpAddNumbers.Name = "tpAddNumbers";
            this.tpAddNumbers.Padding = new System.Windows.Forms.Padding(3);
            this.tpAddNumbers.Size = new System.Drawing.Size(821, 461);
            this.tpAddNumbers.TabIndex = 0;
            this.tpAddNumbers.Text = "Add Numbers";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnBack.Location = new System.Drawing.Point(45, 377);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(176, 45);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "Back To Menu";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            this.btnBack.MouseEnter += new System.EventHandler(this.btnBack_MouseEnter);
            this.btnBack.MouseLeave += new System.EventHandler(this.btnBack_MouseLeave);
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAnswer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(230)))));
            this.lblAnswer.Location = new System.Drawing.Point(334, 281);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(171, 45);
            this.lblAnswer.TabIndex = 5;
            this.lblAnswer.Text = "Answer is: ";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdd.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAdd.Location = new System.Drawing.Point(45, 290);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(176, 45);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add The Numbers";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            this.btnAdd.MouseEnter += new System.EventHandler(this.btnAdd_MouseEnter);
            this.btnAdd.MouseLeave += new System.EventHandler(this.btnAdd_MouseLeave);
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(45, 118);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(63, 15);
            this.lblNum2.TabIndex = 3;
            this.lblNum2.Text = "Number 2:";
            // 
            // txtNum2
            // 
            this.txtNum2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.txtNum2.Location = new System.Drawing.Point(45, 136);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(176, 23);
            this.txtNum2.TabIndex = 2;
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(45, 54);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(63, 15);
            this.lblNum1.TabIndex = 1;
            this.lblNum1.Text = "Number 1:";
            // 
            // txtNum1
            // 
            this.txtNum1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.txtNum1.Location = new System.Drawing.Point(45, 72);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(176, 23);
            this.txtNum1.TabIndex = 0;
            // 
            // tpSubtract
            // 
            this.tpSubtract.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(40)))), ((int)(((byte)(49)))));
            this.tpSubtract.Controls.Add(this.btnBack2);
            this.tpSubtract.Controls.Add(this.lblAnswer2);
            this.tpSubtract.Controls.Add(this.btnSubtract);
            this.tpSubtract.Controls.Add(this.label2);
            this.tpSubtract.Controls.Add(this.txtSubNum2);
            this.tpSubtract.Controls.Add(this.label3);
            this.tpSubtract.Controls.Add(this.txtSubNum1);
            this.tpSubtract.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.tpSubtract.Location = new System.Drawing.Point(4, 27);
            this.tpSubtract.Name = "tpSubtract";
            this.tpSubtract.Padding = new System.Windows.Forms.Padding(3);
            this.tpSubtract.Size = new System.Drawing.Size(821, 461);
            this.tpSubtract.TabIndex = 1;
            this.tpSubtract.Text = "Subtract Numbers";
            // 
            // btnBack2
            // 
            this.btnBack2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnBack2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnBack2.Location = new System.Drawing.Point(52, 377);
            this.btnBack2.Name = "btnBack2";
            this.btnBack2.Size = new System.Drawing.Size(176, 45);
            this.btnBack2.TabIndex = 13;
            this.btnBack2.Text = "Back To Menu";
            this.btnBack2.UseVisualStyleBackColor = false;
            this.btnBack2.Click += new System.EventHandler(this.btnBack_Click);
            this.btnBack2.MouseEnter += new System.EventHandler(this.btnBack_MouseEnter);
            this.btnBack2.MouseLeave += new System.EventHandler(this.btnBack_MouseLeave);
            // 
            // lblAnswer2
            // 
            this.lblAnswer2.AutoSize = true;
            this.lblAnswer2.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAnswer2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(230)))));
            this.lblAnswer2.Location = new System.Drawing.Point(341, 281);
            this.lblAnswer2.Name = "lblAnswer2";
            this.lblAnswer2.Size = new System.Drawing.Size(171, 45);
            this.lblAnswer2.TabIndex = 12;
            this.lblAnswer2.Text = "Answer is: ";
            // 
            // btnSubtract
            // 
            this.btnSubtract.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnSubtract.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSubtract.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSubtract.Location = new System.Drawing.Point(52, 290);
            this.btnSubtract.Name = "btnSubtract";
            this.btnSubtract.Size = new System.Drawing.Size(176, 45);
            this.btnSubtract.TabIndex = 11;
            this.btnSubtract.Text = "Subtract The Numbers";
            this.btnSubtract.UseVisualStyleBackColor = false;
            this.btnSubtract.Click += new System.EventHandler(this.btnSubtract_Click);
            this.btnSubtract.MouseEnter += new System.EventHandler(this.btnAdd_MouseEnter);
            this.btnSubtract.MouseLeave += new System.EventHandler(this.btnAdd_MouseLeave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "Number 2:";
            // 
            // txtSubNum2
            // 
            this.txtSubNum2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.txtSubNum2.Location = new System.Drawing.Point(52, 136);
            this.txtSubNum2.Name = "txtSubNum2";
            this.txtSubNum2.Size = new System.Drawing.Size(176, 23);
            this.txtSubNum2.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Number 1:";
            // 
            // txtSubNum1
            // 
            this.txtSubNum1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.txtSubNum1.Location = new System.Drawing.Point(52, 72);
            this.txtSubNum1.Name = "txtSubNum1";
            this.txtSubNum1.Size = new System.Drawing.Size(176, 23);
            this.txtSubNum1.TabIndex = 7;
            // 
            // tpMulti
            // 
            this.tpMulti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(40)))), ((int)(((byte)(49)))));
            this.tpMulti.Controls.Add(this.btnBack3);
            this.tpMulti.Controls.Add(this.lblAnswer3);
            this.tpMulti.Controls.Add(this.btnMult);
            this.tpMulti.Controls.Add(this.label5);
            this.tpMulti.Controls.Add(this.txtMultNum2);
            this.tpMulti.Controls.Add(this.label6);
            this.tpMulti.Controls.Add(this.txtMultNum1);
            this.tpMulti.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.tpMulti.Location = new System.Drawing.Point(4, 27);
            this.tpMulti.Name = "tpMulti";
            this.tpMulti.Size = new System.Drawing.Size(821, 461);
            this.tpMulti.TabIndex = 2;
            this.tpMulti.Text = "Multiply Numbers";
            // 
            // btnBack3
            // 
            this.btnBack3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnBack3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnBack3.Location = new System.Drawing.Point(53, 377);
            this.btnBack3.Name = "btnBack3";
            this.btnBack3.Size = new System.Drawing.Size(176, 45);
            this.btnBack3.TabIndex = 20;
            this.btnBack3.Text = "Back To Menu";
            this.btnBack3.UseVisualStyleBackColor = false;
            this.btnBack3.Click += new System.EventHandler(this.btnBack_Click);
            this.btnBack3.MouseEnter += new System.EventHandler(this.btnBack_MouseEnter);
            this.btnBack3.MouseLeave += new System.EventHandler(this.btnBack_MouseLeave);
            // 
            // lblAnswer3
            // 
            this.lblAnswer3.AutoSize = true;
            this.lblAnswer3.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAnswer3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(230)))));
            this.lblAnswer3.Location = new System.Drawing.Point(342, 281);
            this.lblAnswer3.Name = "lblAnswer3";
            this.lblAnswer3.Size = new System.Drawing.Size(171, 45);
            this.lblAnswer3.TabIndex = 19;
            this.lblAnswer3.Text = "Answer is: ";
            // 
            // btnMult
            // 
            this.btnMult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnMult.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMult.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnMult.Location = new System.Drawing.Point(53, 290);
            this.btnMult.Name = "btnMult";
            this.btnMult.Size = new System.Drawing.Size(176, 45);
            this.btnMult.TabIndex = 18;
            this.btnMult.Text = "Multiply The Numbers";
            this.btnMult.UseVisualStyleBackColor = false;
            this.btnMult.Click += new System.EventHandler(this.btnMult_Click);
            this.btnMult.MouseEnter += new System.EventHandler(this.btnAdd_MouseEnter);
            this.btnMult.MouseLeave += new System.EventHandler(this.btnAdd_MouseLeave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 15);
            this.label5.TabIndex = 17;
            this.label5.Text = "Number 2:";
            // 
            // txtMultNum2
            // 
            this.txtMultNum2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.txtMultNum2.Location = new System.Drawing.Point(53, 136);
            this.txtMultNum2.Name = "txtMultNum2";
            this.txtMultNum2.Size = new System.Drawing.Size(176, 23);
            this.txtMultNum2.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(53, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Number 1:";
            // 
            // txtMultNum1
            // 
            this.txtMultNum1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.txtMultNum1.Location = new System.Drawing.Point(53, 72);
            this.txtMultNum1.Name = "txtMultNum1";
            this.txtMultNum1.Size = new System.Drawing.Size(176, 23);
            this.txtMultNum1.TabIndex = 14;
            // 
            // MathWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(40)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(829, 492);
            this.Controls.Add(this.tbcMathPages);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MathWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Math Window";
            this.tbcMathPages.ResumeLayout(false);
            this.tpAddNumbers.ResumeLayout(false);
            this.tpAddNumbers.PerformLayout();
            this.tpSubtract.ResumeLayout(false);
            this.tpSubtract.PerformLayout();
            this.tpMulti.ResumeLayout(false);
            this.tpMulti.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tbcMathPages;
        private TabPage tpAddNumbers;
        private TabPage tpSubtract;
        private TabPage tpMulti;
        private Label lblNum1;
        private TextBox txtNum1;
        private Label lblNum2;
        private TextBox txtNum2;
        private Button btnAdd;
        private Label lblAnswer;
        private Button btnBack;
        private Button btnBack2;
        private Label lblAnswer2;
        private Button btnSubtract;
        private Label label2;
        private TextBox txtSubNum2;
        private Label label3;
        private TextBox txtSubNum1;
        private Button btnBack3;
        private Label lblAnswer3;
        private Button btnMult;
        private Label label5;
        private TextBox txtMultNum2;
        private Label label6;
        private TextBox txtMultNum1;
    }
}