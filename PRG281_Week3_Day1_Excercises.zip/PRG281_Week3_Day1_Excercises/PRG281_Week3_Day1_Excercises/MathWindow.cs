﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG281_Week3_Day1_Excercises
{
    public partial class MathWindow : Form
    {
        public MathWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_MouseEnter(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.FromArgb(255, 57, 62, 70);
            btnSubtract.BackColor = Color.FromArgb(255, 57, 62, 70);
            btnMult.BackColor = Color.FromArgb(255, 57, 62, 70);
        }

        private void btnAdd_MouseLeave(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.FromArgb(255, 0, 173, 181);
            btnSubtract.BackColor = Color.FromArgb(255, 0, 173, 181);
            btnMult.BackColor = Color.FromArgb(255, 0, 173, 181);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            double Number1 = 0;
            double Number2 = 0;

            try
            {
                Number1 = Convert.ToDouble(txtNum1.Text);
                Number2 = Convert.ToDouble(txtNum2.Text);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally
            {
                lblAnswer.Text = $"Answer is: {Number1+Number2}";
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MainMenu menuForm = new MainMenu();
            menuForm.Show();
            this.Hide();
        }

        private void btnBack_MouseEnter(object sender, EventArgs e)
        {
            btnBack.BackColor = Color.FromArgb(255, 57, 62, 70);
            btnBack2.BackColor = Color.FromArgb(255, 57, 62, 70);
            btnBack3.BackColor = Color.FromArgb(255, 57, 62, 70);
        }

        private void btnBack_MouseLeave(object sender, EventArgs e)
        {
            btnBack.BackColor = Color.FromArgb(255, 0, 173, 181);
            btnBack2.BackColor = Color.FromArgb(255, 0, 173, 181);
            btnBack3.BackColor = Color.FromArgb(255, 0, 173, 181);
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            double Number1 = 0;
            double Number2 = 0;

            try
            {
                Number1 = Convert.ToDouble(txtSubNum1.Text);
                Number2 = Convert.ToDouble(txtSubNum2.Text);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                lblAnswer2.Text = $"Answer is: {Number1 - Number2}";
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            double Number1 = 0;
            double Number2 = 0;

            try
            {
                Number1 = Convert.ToDouble(txtMultNum1.Text);
                Number2 = Convert.ToDouble(txtMultNum2.Text);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                lblAnswer3.Text = $"Answer is: {Number1 * Number2}";
            }
        }
    }
}
