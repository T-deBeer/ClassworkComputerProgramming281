using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace PRG281_Week3_Day1_Excercises
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMath_MouseHover(object sender, EventArgs e)
        {
            btnMath.BackColor = Color.FromArgb(255, 57, 62, 70);
            
        }

        private void btnMath_MouseLeave(object sender, EventArgs e)
        {
            btnMath.BackColor = Color.FromArgb(255, 0, 173, 181);
        }

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.FromArgb(255, 57, 62, 70);
        }

        private void btnExit_MouseLeave(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.FromArgb(255, 0, 173, 181);
        }

        private void btnMath_Click(object sender, EventArgs e)
        {
            MathWindow mathForm = new MathWindow();
            mathForm.Show();
            this.Hide();
        }

        private void btnDgv_MouseEnter(object sender, EventArgs e)
        {
            btnDgv.BackColor = Color.FromArgb(255, 57, 62, 70);
        }

        private void btnDgv_MouseLeave(object sender, EventArgs e)
        {
            btnDgv.BackColor = Color.FromArgb(255, 0, 173, 181);
        }

        private void btnDgv_Click(object sender, EventArgs e)
        {
            DataGridForm form = new DataGridForm();

            form.Show();
            this.Hide();
        }

        private void btnTaxCalculator_MouseEnter(object sender, EventArgs e)
        {
            btnTaxCalculator.BackColor = Color.FromArgb(255, 57, 62, 70);
        }

        private void btnTaxCalculator_MouseLeave(object sender, EventArgs e)
        {
            btnTaxCalculator.BackColor = Color.FromArgb(255, 0, 173, 181);
        }

        private void btnTaxCalculator_Click(object sender, EventArgs e)
        {
            TaxCalculator form = new TaxCalculator();
            form.Show();
            this.Hide();
        }
    }

    
}